module.exports = (req, resp, next)=>{
    
    const { authorization } = req.headers;

    if(authorization){
        next();
    }else{
        resp.status(401).send({error: "Token is missing in request header"})
    }  

}