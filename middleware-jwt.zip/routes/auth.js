const express = require('express');
const jwt = require('jsonwebtoken');


const router = express.Router();

const _username = "waviz";
const _password = "waviz@123"


router.post('/login', (req, resp)=>{

    const {username, password } = req.body;

    if(username === _username && password === _password){

       const payload = { username: 'waviz' , role:"employee", permission:['employee.view']}

        const token = jwt.sign(payload, '2b53161bacbf03efeb87b266edcda7675c29a0417947902a68b3175bacb7982780cd84853e746bb4db74f443696ea70e');

        const userInfo = {
            username,
            token
        }

        resp.send(userInfo);
    }
    else{
        resp.status(401).send("username and password is not correct");
    }
})

module.exports = router;