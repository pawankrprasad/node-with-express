const express = require('express');
const router = express.Router();


let employees = [
    {id:101, name:"Employee1", phone:"1234567", email:"emp1@gmail.com"},
    {id:102, name:"Employee1", phone:"1234567", email:"emp1@gmail.com"},
    {id:103, name:"Employee1", phone:"1234567", email:"emp1@gmail.com"},
    {id:104, name:"Employee1", phone:"1234567", email:"emp1@gmail.com"}
]

router.get('/', (req, res)=>{
    res.send(employees)
});


// GET pathparameter
router.get('/:id', (req, res)=>{
    const { id } = req.params;
    const employee = employees.find(e => e.id==id)
    console.log(employee);
    res.send(employee)
});

router.post('/', (req, res)=>{
    const data = req.body;
    employees.push(data);
    res.send(data);
});

router.delete('/:id', (req, res)=>{
    const {id} = req.params;

    employees = employees.filter(e => e.id!=id);
    res.send("Employee deleted");
    
});

router.put('/:id', (req, res)=>{
    const {id} = req.params;
    const data = req.body;
    employees.forEach(emp => {
        if(emp.id==id){
            Object.keys(emp).forEach(key=>{
                if(data[key]){
                    emp[key] = data[key]
                }
                
            })
        }
    })
    res.send("Employee updated");
});



module.exports = router;